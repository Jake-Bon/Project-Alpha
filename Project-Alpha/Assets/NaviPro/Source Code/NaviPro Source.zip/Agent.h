/*
Distributed under the Unity Asset Store EULA as given in
https://unity3d.com/legal/as_terms
*/

#pragma once

#include "ExplicitCorridorMap.h"
#include "NavigationPoint.h"
#include "NavigationPath.h"
#include "AgentStatus.h"



extern "C" struct AgentProperties
{
	// The physical size of the agent, ie. its collision shape, measured from the agent's center
	float radius;
	// The preferred minimal distance to other agents, measured from the agent's side
	float personalSpaceDistance;
	// The preferred distance to obstacles in an open area, measured from the agent's side
	float safeDistance;
	// The range within which the Agent can see other agents, measured from the agent's center to other agent's side
	float visibilityRadius;
	// The maximum movement speed in meters per second
	float movementSpeed;
	// The maximum acceleration in meters per second^2
	float acceleration;
	// The maximum turning speed in radians per second
	float turnSpeed;
	// The maximum turning acceleration in radians per second^2
	float turnAcceleration;
	// Factors that limit sideways and backwards speed and acceleration with respect to the forward direction
	float sidewaysMovementFactor;
	float backwardsMovementFactor;
};


/**
 * Agents are entities, often describing pedestrians or something similar, that move across the walkable surface towards a given goal.
 * They are modeled in 2D using a circular shape for collision.
 * Agents have various properties that describe their size and behaviour, such as their physical radius and maximum movement speed.
 * 
 * Agents use path finding, supported by NavigationPath, to find a route towards their goal. They steer along this path, while
 * evading walls and other agents.
 * The steering behaviour is described in SimulateMovement, using a force based method to derive a desired speed. The combined forces
 * include a pathing force, boundary force, collision avoidance force and a small random force. A final adjustment of the desired speed
 * applies collision resolution.
 * In ApplySimulatedMovement, the desired speed is then used to generate a new acceleration and change the current speed and orientation.
 * 
 * Agents can be disabled, at which point they are no longer treated as being in any Sector. Calling MoveTo will reenable the Agent.
 */
class Agent
{
	typedef bg::model::box<Vec2> box;

	struct Path
	{
		std::list<Vec3> goals;
		NavigationPath path;
		NavigationPath::Point nearestPoint;
		double remainingDistance;
		double remainingDistanceFromNearestPoint;

		// Reevaluate the path, returns true if the path was changed
		bool Recompute(const Agent & agent, bool forceRecompute = false);

		AgentStatusGoal UpdateGoalStatus(double nearGoalDistance, double atGoalDistance, const Agent & agent);

		Vec2 GetNearestPoint() const;
	};

public:
	Agent();

	// Sets the agent properties, either after creation or as a change later
	void SetProperties(AgentProperties properties);

	// Immediately disables the Agent, removing it from its Sector
	void Disable();
	// Moves the Agent to the given position with the given orientation in Sector space
	// Any path the agent was following will be recomputated
	// The orientation is 0 along the x axis and rotates towards the y axis at pi / 2
	void MoveTo(Sector * sector, Vec3 position, double orientation);
	// Specifies a new goal in Sector space
	// Setting a new goal clears all previous goals
	void SetGlobalGoal(Vec3 position);
	// Specifies a new goal in Sector space
	// It will be followed after previous goals have been reached
	void AddGlobalGoal(Vec3 position);
	// Clears all goals
	void ClearGlobalGoal();

	// To be called right before SimulateMovement, this checks whether the Agent position should be relocated
	// This function is thread safe
	bool PrepareForSimulation();
	// Based on the current state of this and nearby agents, determine the preferred movement
	// This function is thread safe
	void SimulateMovement(double deltaTime);
	// Moves the agent by the simulated movement and replaces the agent on the TriangleMesh
	// This function is thread safe
	void ApplySimulatedMovement(double deltaTime);
	// Updates the spatial index entry for this agent
	// To be called after ApplySimulatedMovement
	// This function is NOT thread safe
	void UpdateSpatialIndexing();

	// Adds this Agent to the given Sector's spatial index
	void AddToSpatialIndex(Sector * sector, const Vec2 & newPosition);
	// Removes this Agent from the given Sector's spatial index
	void RemoveFromSpatialIndex(Sector * sector);

	// Returns the current position in Sector space
	const Vec3 & GetPosition() const;
	// Returns the current orientation
	// The orientation is 0 along the x axis and rotates towards the y axis at pi / 2
	double GetOrientation() const;
	// Returns the current speed in Sector space
	Vec2 GetSpeed() const;
	// Returns the current speed in Agent local space, where x is forward and y is left
	Vec2 GetLocalSpeed() const;
	// Returns the current NavigationPoint
	const NavigationPoint & GetNavigationPoint() const;
	// Returns the Sector on which the Agent is placed
	Sector * GetSector() const;
	// Checks whether the Agent is enabled, ie. placed on a valid point on the Sector
	bool IsEnabled() const;

	// Returns the radius
	double GetRadius() const;
	// Returns the sight radius, measured from the center of the agent
	double GetSightRadius() const;
	// Returns the personal radius, measured from the center of the agent
	double GetPersonalSpaceRadius() const;
	// Returns an adaptive variant of the above GetPersonalSpaceRadius()
	// This ranges between the radius and the personal space radius based on local crowd density
	double GetAdaptivePersonalSpaceRadius() const;
	// Returns the forward vector in Sector space, derived from the orientation
	Vec2 GetForwardVector() const;
	// Checks whether the Agent's current position is on a Platform
	// This is useful for correctly determining the Agent's height
	bool IsOnPlatform() const;

	// Returns the current status of the Agent
	AgentStatusGoal GetGoalStatus() const;
	AgentStatusPath GetPathStatus() const;

	// When a new walkable area becomes available, this should be called for each agent to possibly update their pathing
	// This allows agents to use the new walkable area for a faster path
	void NotifyNewWalkableArea(const Polygon & polygon);

	// This is a boolean state that can be set to indicate the Agent should not compute its own desiredSpeed
	bool customControl;
	// To be called before SimulateMovement() if customControl is true to communicate the desiredSpeed to the Agent
	void SetDesiredSpeed(Vec2 desiredSpeed);
	// The following calls can be used when customControl is true
	// They provide the same information of the Agent's surroundings as is used in SimulateMovement()
	std::tuple<Vec2, double> GetNearestObstacleAndCenterObstacleDistance() const;
	std::tuple<Vec2, Vec2, Vec2> GetSuggestedPathing(Vec2 nearestObstacle, double centerObstacleDistance);

private:
	NavigationPoint position;
	bool isOnPlatform;

	Path globalPath;

	// The physical size of the agent, ie. its collision shape, measured from the agent's center
	double radius;
	// The preferred minimal distance to other agents, measured from the agent's side
	double personalSpaceDistance;
	// The preferred distance to obstacles in an open area, measured from the agent's center (changed from AgentProperties)
	double safeDistance;
	// The range within which the Agent can see other agents, measured from the agent's center to other agent's side
	double visibilityRadius;
	// The maximum movement speed in meters per second
	double maxMovementSpeed;
	// The maximum acceleration in meters per second^2
	double maxAcceleration;
	// The maximum turning speed in radians per second
	double maxTurningSpeed;
	// The maximum turning acceleration in radians per second^2
	double turnAcceleration;
	// Factors that limit sideways and backwards speed and acceleration with respect to the forward direction
	double sidewaysMovementFactor;
	double backwardsMovementFactor;

	// The current movement speed of the agent
	Vec2 speed;
	// Forward orientation of the agent in radians: 0 is towards +x, pi/2 is towards +y
	double orientation;
	// Current turnSpeed in radians as a derivative of orientation: positive is left (facing to +x, left is +y), negative is right
	double turnSpeed;

	// This speed is computed by calling SimulateMovement and is used during ApplySimulatedMovement
	Vec2 desiredSpeed;
	// This orientation is computed during SimulateMovement based on desiredSpeed
	double desiredOrientation;
	// This is the crowd density as computed and used during SimulateMovement
	double localCrowdDensity;

	box spatialIndexingBox;
	bool spatialIndexingNeedsUpdate;

	// The current status of the Agent
	AgentStatusGoal statusGoal;
	AgentStatusPath statusPath;
	// Kept to check whether an invalidation of the path was caused by moving the Agent or finding a faster path
	// Otherwise such an invalidation is due to an obstruction
	bool statusSetPathChanged;


	void computeLocalCrowdDensity(const std::vector<Agent *> & nearbyAgents, double centerObstacleDistance);

	// Returns the pathing force, ie the attraction force for this Agent to follow the set path
	Vec2 getPathingForce(Path & path, Vec2 nearestObstacle, double centerObstacleDistance, double nearGoalFactor);
	std::tuple<Vec2, Vec2> getNearestPointAndDirection(Path & path, double clearDistance);

	// Returns the soft boundary force, where the Agent tries to maintain a safe distance to obstacles
	Vec2 getBoundaryForce(Vec2 obstaclePoint, double centerObstacleDistance, double remainingDistance, double nearGoalFactor, double deltaTime) const;

	// Returns the collision force, where the Agent tries to avoid getting too close to other agents
	Vec2 getCollisionForce(const std::vector<Agent *> & nearbyAgents) const;

	// Returns a small deterministic random force based on the Agent's position
	Vec2 getRandomForce() const;


	// Applies the effect of crowd streams to the agent's desired speed, copying the speed of other agents nearby
	void applyCrowdStream(Vec2 & desiredSpeed, const std::vector<Agent *> & nearbyAgents) const;

	// Applies the effect of collision avoidance, where the Agent predicts and avoids collision with  other agents
	void applyCollisionAvoidance(Vec2 & desiredSpeed, const std::vector<Agent *> & nearbyAgents, double remainingDistance) const;

	// Reduces the desired speed in the direction of the given obstacle when the Agent is very close to the obstacle
	void reduceDesiredSpeedIntoBoundary(Vec2 & desiredSpeed, Vec2 obstaclePoint);

	// Applies the effect of collision resolution, where the Agent is pushed out of collisions based on the amount of overlap
	void applyCollisionResolution(Vec2 & desiredSpeed, Vec2 nearestObstacle, const std::vector<Agent *> & nearbyAgents) const;


	static bool lineSegmentIntersectsCircle(Vec2 lineStart, Vec2 lineDirection, Vec2 circleCenter, double circleRadius, double & t1, double & t2);

	static void limitMagnitudeByDirectionalFactors(Vec2 & vector, double magnitude, const Vec2 & forwardVector, double forwardFactor, double sidewaysFactor, double backwardsFactor, const Vec2 & factorDirection, bool adjustInFactorDirectionOnly);
	static void applyDirectionalFactors(Vec2 & vector, const Vec2 & forwardVector, double forwardFactor, double sidewaysFactor, double backwardsFactor, const Vec2 & factorDirection, bool adjustInFactorDirectionOnly);
};


/**
 * AgentSet is a set of Agents, stored in a spatial datastructure for efficient lookups.
 * The query function allows finding nearby agents and the set is iterable through the begin and end functions.
 */
class AgentSet
{
public:
	typedef bg::model::box<Vec2> box;
	typedef std::pair<box, Agent *> value;

	// Copies of AgentSets will be empty, they should not be copied anyway
	// This is a workaround for the non-copyable mutex
	AgentSet()
	{}
	AgentSet(const AgentSet & set)
	{}

	// These two functions iterate through all agents in the set
	// They are not thread safe
	std::set<Agent *>::iterator begin() const
	{
		return agents.begin();
	}
	std::set<Agent *>::iterator end() const
	{
		return agents.end();
	}

	// Insert or remove an Agent
	void insert(Agent * agent, const box & box)
	{
		rtree.insert(std::make_pair(box, agent));
		agents.emplace(agent);
	}
	void remove(Agent * agent, const box & box)
	{
		rtree.remove(std::make_pair(box, agent));
		agents.erase(agent);
	}

	// Finds all agents within a radius from the given NavigationPoint
	// Checks include the radius of the agent, so that the distance compared to an agent position is radius + agent radius
	// Also checks whether the agent is directly reachable across the navigation mesh (skips agents on other layers and behind walls)
	std::vector<Agent *> query(const NavigationPoint & point, double radius)
	{
		std::vector<value> results;
		Vec2 position = point.GetLocalPosition();
		rtree.query(bgi::intersects(box(position - Vec2(radius, radius), position + Vec2(radius, radius))), std::back_inserter(results));
		std::vector<Agent *> resultAgents;
		for (auto & result : results)
		{
			// Check range
			if ((position - result.second->GetPosition()).length() > radius + result.second->GetRadius())
				continue;
			// Check visibility
			if (!point.CanSeePoint(result.second->GetNavigationPoint()))
				continue;
			resultAgents.emplace_back(result.second);
		}
		return resultAgents;
	}

	// Finds all agents within a radius from the given position
	// Unlike the NavigationPoint variant, this version does not check for visibility
	std::vector<Agent *> query(const Vec2 & position, double radius)
	{
		std::vector<value> results;
		rtree.query(bgi::intersects(box(position - Vec2(radius, radius), position + Vec2(radius, radius))), std::back_inserter(results));
		std::vector<Agent *> resultAgents;
		for (auto & result : results)
		{
			// Check range
			if ((position - result.second->GetPosition()).length() > radius + result.second->GetRadius())
				continue;
			resultAgents.emplace_back(result.second);
		}
		return resultAgents;
	}

private:
	bgi::rtree<value, bgi::quadratic<8>> rtree;
	std::set<Agent *> agents;
};
