/*
Distributed under the Unity Asset Store EULA as given in
https://unity3d.com/legal/as_terms
*/

#include "global.h"
#include "Agent.h"

#include "Sector.h"



bool Agent::Path::Recompute(const Agent & agent, bool forceRecompute)
{
	if (goals.empty() || !agent.position.IsOnECM())
	{
		goals.clear();
		path.Clear();
		return true;
	}

	if (!forceRecompute && path.IsSet())
	{
		NavigationPath newPath;
		newPath.Set(agent.position, goals.front(), agent.radius, agent.safeDistance);
		bool replacePath = true;
		if (agent.statusPath == AGENTSTATUS_PATH_FASTER_PATH_FOUND_AND_UPDATED || agent.statusPath == AGENTSTATUS_PATH_IMPROVED_PATH_FOUND_AND_UPDATED)
		{
			if ((path.ReachesGoal() && newPath.ReachesGoal()) || (!path.ReachesGoal() && !newPath.ReachesGoal()))
				replacePath = newPath.GetDistanceWeighting() < path.GetDistanceWeighting(remainingDistance);
			else if (path.ReachesGoal() && !newPath.ReachesGoal())
				replacePath = false;
		}
		if (replacePath)
		{
			path.CopyFrom(newPath);
			path.ClearNeedsReplanning();
			nearestPoint = NavigationPath::Point(0, 0.0);
			remainingDistance = path.GetTotalLength();
			remainingDistanceFromNearestPoint = remainingDistance;
			return true;
		}
		else
		{
			path.ClearNeedsReplanning();
			return false;
		}
	}
	else
	{
		path.Set(agent.position, goals.front(), agent.radius, agent.safeDistance);
		nearestPoint = NavigationPath::Point(0, 0.0);
		remainingDistance = path.GetTotalLength();
		remainingDistanceFromNearestPoint = remainingDistance;
		return true;
	}
}

AgentStatusGoal Agent::Path::UpdateGoalStatus(double nearGoalDistance, double atGoalDistance, const Agent & agent)
{
	if (goals.empty())
		return AGENTSTATUS_GOAL_NO_GOAL_SET;

	if (remainingDistance <= nearGoalDistance || (agent.statusGoal == AGENTSTATUS_GOAL_NEARING_GOAL_SLOWING_DOWN || agent.statusGoal == AGENTSTATUS_GOAL_NEARING_POINT_NEAR_GOAL_SLOWING_DOWN))
	{
		Vec2 toPathEnd = path.GetEndPoint() - agent.GetPosition();
		if (goals.size() > 1 || toPathEnd.length() <= atGoalDistance)
		{
			if (path.ReachesGoal())
			{
				goals.pop_front();
				Recompute(agent, true);
				if (goals.empty())
					return AGENTSTATUS_GOAL_GOAL_REACHED;
				else
					return AGENTSTATUS_GOAL_NEARING_GOAL_MOVING_TO_NEXT;
			}
			else
			{
				path.Clear();
				return AGENTSTATUS_GOAL_POINT_NEAR_GOAL_REACHED;
			}
		}
		else if (!path.ReachesGoal())
		{
			return AGENTSTATUS_GOAL_NEARING_POINT_NEAR_GOAL_SLOWING_DOWN;
		}
		else
		{
			return AGENTSTATUS_GOAL_NEARING_GOAL_SLOWING_DOWN;
		}
	}

	if (path.ReachesGoal())
		return AGENTSTATUS_GOAL_MOVING_TOWARDS_GOAL;
	else
		return AGENTSTATUS_GOAL_MOVING_TOWARDS_POINT_NEAR_GOAL;
}

Vec2 Agent::Path::GetNearestPoint() const
{
	return lerp(path.GetPoints()[nearestPoint.segment], path.GetPoints()[nearestPoint.segment + 1], nearestPoint.t);
}


Agent::Agent()
	: statusGoal(AGENTSTATUS_GOAL_NO_GOAL_SET), statusPath(AGENTSTATUS_PATH_NOT_FOLLOWING_PATH), statusSetPathChanged(false), customControl(false)
{}

void Agent::SetProperties(AgentProperties properties)
{
	radius = properties.radius;
	personalSpaceDistance = properties.personalSpaceDistance;
	safeDistance = properties.radius + properties.safeDistance;
	visibilityRadius = properties.visibilityRadius;
	maxMovementSpeed = properties.movementSpeed;
	maxAcceleration = properties.acceleration;
	speed = Vec2(0.0, 0.0);
	orientation = 0.0;
	turnSpeed = 0.0;
	maxTurningSpeed = properties.turnSpeed;
	turnAcceleration = properties.turnAcceleration;
	sidewaysMovementFactor = properties.sidewaysMovementFactor;
	backwardsMovementFactor = properties.backwardsMovementFactor;
}

void Agent::Disable()
{
	if (position.IsSet())
		RemoveFromSpatialIndex(position.GetSector());
	position.UnSet();
	globalPath.goals.clear();
	globalPath.path.Clear();
}

void Agent::MoveTo(Sector * sector, Vec3 position, double orientation)
{
	if (this->position.IsSet() && this->position.GetSector() != sector)
		RemoveFromSpatialIndex(this->position.GetSector());
	if (!this->position.IsSet() || this->position.GetSector() != sector)
		AddToSpatialIndex(sector, position);

	if (!sector->mesh.Sample(position, isOnPlatform, true, sector->maximumSnappingHeight) || !this->position.Set(sector, position))
	{
		RemoveFromSpatialIndex(sector);
		Disable();
	}
	this->orientation = orientation;
	if (globalPath.path.IsSet())
	{
		globalPath.path.SetNeedsReplanning();
		statusPath = AGENTSTATUS_PATH_MOVED_AGENT_PATH_UPDATED;
		statusSetPathChanged = true;
	}
}

void Agent::SetGlobalGoal(Vec3 goalPosition)
{
	// Prevent path being recomputed if the same goal is set repeatedly
	if (!globalPath.goals.empty() && globalPath.goals.front() == goalPosition)
	{
		globalPath.goals.clear();
		globalPath.goals.push_back(goalPosition);
		return;
	}

	globalPath.goals.clear();
	globalPath.goals.push_back(goalPosition);
	globalPath.Recompute(*this, true);
	statusPath = AGENTSTATUS_PATH_FOLLOWING_PATH;
	statusGoal = (globalPath.path.ReachesGoal() ? AGENTSTATUS_GOAL_MOVING_TOWARDS_GOAL : AGENTSTATUS_GOAL_MOVING_TOWARDS_POINT_NEAR_GOAL);
}
void Agent::AddGlobalGoal(Vec3 position)
{
	if (globalPath.goals.empty())
		SetGlobalGoal(position);
	else
		globalPath.goals.push_back(position);
}
void Agent::ClearGlobalGoal()
{
	if (globalPath.goals.empty())
		return;
	globalPath.goals.clear();
	globalPath.Recompute(*this);
	statusPath = AGENTSTATUS_PATH_NOT_FOLLOWING_PATH;
	statusGoal = AGENTSTATUS_GOAL_NO_GOAL_SET;
}



bool Agent::PrepareForSimulation()
{
	if (!position.IsSet())
		return true;

	if (position.NeedsRelocation() && !position.Relocate())
	{
		Disable();
		return false;
	}
	return true;
}

void Agent::SimulateMovement(double deltaTime)
{
	if (!position.IsSet())
		return;

	// Check if the path is no longer valid due to an obstruction, replanning, moving the agent or losing a line of sight to the path
	bool isPathVisible = true;
	if (globalPath.path.IsSet())
		isPathVisible = position.CanSeePoint(globalPath.GetNearestPoint());
	if (globalPath.path.NeedsReplanning() || !isPathVisible)
	{
		if (globalPath.Recompute(*this))
		{
			// If !statusSetPathChanged, the change is not due to replanning or moving the agent,
			// but by the path becoming invalid due to obstruction
			if (!statusSetPathChanged)
				statusPath = AGENTSTATUS_PATH_PATH_OBSTRUCTED_AND_UPDATED;
			// If the nearest path point is no longer visible, the agent has strayed from the path
			else if (!isPathVisible)
				statusPath = AGENTSTATUS_PATH_PATH_LOST_AND_UPDATED;
			statusGoal = globalPath.path.ReachesGoal() ? AGENTSTATUS_GOAL_MOVING_TOWARDS_GOAL : AGENTSTATUS_GOAL_MOVING_TOWARDS_POINT_NEAR_GOAL;
		}
		else
			statusPath = AGENTSTATUS_PATH_FOLLOWING_PATH;
	}
	else if (!statusSetPathChanged)
	{
		if (globalPath.path.IsSet())
			statusPath = AGENTSTATUS_PATH_FOLLOWING_PATH;
		else
			statusPath = AGENTSTATUS_PATH_NOT_FOLLOWING_PATH;
	}
	statusSetPathChanged = false;

	Path * activePath = nullptr;
	if (globalPath.path.IsSet())
		activePath = &globalPath;

	auto nearestObstacle = ExplicitCorridorMap::FindNearestObstaclePointAtPoint(position.GetEdgeSegment().get(), position.GetLocalPosition());
	auto nearbyAgents = position.GetSector()->agentSet.query(position, GetSightRadius());
	double centerObstacleDistance = (position.GetEdgeSegment()->getClosestPointOnMedialAxisAtPoint(GetPosition()) - nearestObstacle).length();

	// Simplification based on: s = 0.5 a t^2 + 0.5 a t dt  where  t = (v / a)
	double nearGoalDistance = 0.5 * maxMovementSpeed * maxMovementSpeed / maxAcceleration + 0.5 * maxMovementSpeed * deltaTime;

	Vec2 toGoal;
	double desiredSpeedToGoal;

	computeLocalCrowdDensity(nearbyAgents, centerObstacleDistance);

	if (activePath)
	{
		toGoal = activePath->path.GetEndPoint() - GetPosition();
		// Simplification based on: s = 0.5 a t^2 + 0.5 a t dt  where  v = a * t
		// Results in: v = sqrt((a * dt / 2)^2 + 2 s a)) - (a * dt / 2)
		double discretizationTerm = maxAcceleration * deltaTime * 0.5;
		desiredSpeedToGoal = sqrt(discretizationTerm * discretizationTerm + 2.0 * toGoal.length() * maxAcceleration) - discretizationTerm;

		double atGoalDistance = lerp(radius, radius * 0.1, std::max(0.0, toGoal.normalized().dot(speed) / std::max(0.001 * maxMovementSpeed, desiredSpeedToGoal)));
		statusGoal = activePath->UpdateGoalStatus(nearGoalDistance, atGoalDistance, *this);
		if (!activePath->path.IsSet())
			activePath = nullptr;
	}
	else if (statusGoal != AGENTSTATUS_GOAL_POINT_NEAR_GOAL_REACHED)
		statusGoal = AGENTSTATUS_GOAL_NO_GOAL_SET;

	if (!customControl)
	{
		Vec2 force(0.0, 0.0);
		if (activePath)
		{
			double nearGoalFactor = std::min(std::max(2.0 - activePath->remainingDistance / nearGoalDistance, 0.0), 1.0);

			// First compute the force driving the individual pathing
			force = getPathingForce(*activePath, nearestObstacle, centerObstacleDistance, nearGoalFactor);
			force += getBoundaryForce(nearestObstacle, centerObstacleDistance, activePath->remainingDistance, nearGoalFactor, deltaTime);
			force += getCollisionForce(nearbyAgents);
			force += getRandomForce();
		}

		// Compute the associated desired speed
		desiredSpeed = force.safe_normalized() * maxMovementSpeed;

		if (activePath)
		{
			// Slow down near goal and steer towards it
			if (statusGoal == AGENTSTATUS_GOAL_NEARING_GOAL_SLOWING_DOWN || statusGoal == AGENTSTATUS_GOAL_NEARING_POINT_NEAR_GOAL_SLOWING_DOWN)
			{
				desiredSpeed = toGoal.normalized() * desiredSpeedToGoal;
			}
		}

		if (activePath)
		{
			// Compute change in speed to effect collision avoidance
			applyCollisionAvoidance(desiredSpeed, nearbyAgents, activePath->remainingDistance);

			// Add crowd flow here, adjusts desiredSpeed
			applyCrowdStream(desiredSpeed, nearbyAgents);

			reduceDesiredSpeedIntoBoundary(desiredSpeed, nearestObstacle);
		}
	}

	if (desiredSpeed.dot(desiredSpeed) > 0.0)
		desiredOrientation = atan2(desiredSpeed.y, desiredSpeed.x);
	else
		desiredOrientation = orientation;
	// Make the agent want to turn less the lower the speed is
	// This also prevents the agent wanting to turn towards the x-axis when desiredSpeed is zero
	double orientationDiff = normalizeAngle(desiredOrientation - orientation);
	desiredOrientation = normalizeAngle(orientation + orientationDiff * std::min(2.0 * desiredSpeed.length() / maxMovementSpeed, 1.0));

	// Limit desiredspeed to maximum
	if (desiredSpeed.length() > maxMovementSpeed)
		desiredSpeed = desiredSpeed.normalized() * maxMovementSpeed;

	// Collision resolution here
	applyCollisionResolution(desiredSpeed, nearestObstacle, nearbyAgents);
}


void Agent::ApplySimulatedMovement(double deltaTime)
{
	if (!position.IsSet())
		return;

	// Turn in the direction of the desired orientation
	double orientationDiff = normalizeAngle(desiredOrientation - orientation);
	// Adjust turning speed by turning acceleration
	// Simplification based on: s = 0.5 a t^2 + 0.5 a t dt  where  v = a * t
	// Results in: v = sqrt((a * dt / 2)^2 + 2 s a)) - (a * dt / 2)
	double adaptiveTurnAcceleration = turnAcceleration *(abs(orientationDiff) / M_PI * 0.6 + 0.4);
	double discretizationTerm = adaptiveTurnAcceleration * deltaTime * 0.5;
	double desiredTurnSpeed = copysign(sqrt(discretizationTerm * discretizationTerm + 2.0 * std::abs(orientationDiff) * adaptiveTurnAcceleration) - discretizationTerm, orientationDiff);
	// Correct for small changes in orientation
	if (std::abs(orientationDiff) < std::abs(desiredTurnSpeed) * deltaTime)
		desiredTurnSpeed = orientationDiff / deltaTime;
	double turnSpeedDiff = desiredTurnSpeed - turnSpeed;
	if (std::abs(turnSpeedDiff) > adaptiveTurnAcceleration * deltaTime)
		turnSpeedDiff = copysign(adaptiveTurnAcceleration * deltaTime, turnSpeedDiff);
	turnSpeed += turnSpeedDiff;
	if (std::abs(turnSpeed) > maxTurningSpeed)
		turnSpeed = copysign(maxTurningSpeed, turnSpeed);
	// Limit orientation difference by turning speed
	//if (std::abs(orientationDiff) > maxTurningSpeed * deltaTime)
	//	orientationDiff = copysign(maxTurningSpeed * deltaTime, orientationDiff);
	orientation = normalizeAngle(orientation + turnSpeed * deltaTime);

	Vec2 deltaSpeed = desiredSpeed - speed;
	// Clamp to maximum acceleration with directional factors
	// Any deltaSpeed component that reduces speed is regarded as a breaking move and is not affected by the directional factors
	limitMagnitudeByDirectionalFactors(deltaSpeed, maxAcceleration * deltaTime, GetForwardVector(), 1.0, sidewaysMovementFactor, backwardsMovementFactor, speed, true);
	// Adjust speed with given acceleration
	speed += deltaSpeed;
	// Limit speed to maximum movement speed with reduced sideways and backwards speed
	limitMagnitudeByDirectionalFactors(speed, maxMovementSpeed, GetForwardVector(), 1.0, sidewaysMovementFactor, backwardsMovementFactor, speed, false);

	Vec3 oldPosition = position.GetLocalPosition();
	Vec3 newPosition = oldPosition + speed * deltaTime;
	if (!position.GetSector()->mesh.Sample(newPosition, isOnPlatform, false, 0.0))
		return;
	// This MoveTo does not allow the Agent to step off the ECM
	if (!position.MoveTo(newPosition, false))
		return;

	if (newPosition.x - radius < spatialIndexingBox.min_corner().x || newPosition.x + radius > spatialIndexingBox.max_corner().x ||
		newPosition.y - radius < spatialIndexingBox.min_corner().y || newPosition.y + radius > spatialIndexingBox.max_corner().y)
		spatialIndexingNeedsUpdate = true;
}

void Agent::UpdateSpatialIndexing()
{
	if (spatialIndexingNeedsUpdate)
	{
		RemoveFromSpatialIndex(position.GetSector());
		AddToSpatialIndex(position.GetSector(), position.GetLocalPosition());
		spatialIndexingNeedsUpdate = false;
	}
}

void Agent::AddToSpatialIndex(Sector * sector, const Vec2 & newPosition)
{
	std::hash<double> hash;
	std::default_random_engine random_engine((int)(hash(newPosition.x) ^ hash(newPosition.y)));
	std::uniform_real_distribution<double> uniform(0.0, 1.0);

	float spacing = radius + maxMovementSpeed * (uniform(random_engine) + 1.0);
	spatialIndexingBox = box(newPosition - Vec2(spacing, spacing), newPosition + Vec2(spacing, spacing));
	sector->agentSet.insert(this, spatialIndexingBox);
}
void Agent::RemoveFromSpatialIndex(Sector * sector)
{
	sector->agentSet.remove(this, spatialIndexingBox);
}


const Vec3 & Agent::GetPosition() const
{
	return position.GetLocalPosition();
}

double Agent::GetOrientation() const
{
	return orientation;
}

Vec2 Agent::GetSpeed() const
{
	return speed;
}

Vec2 Agent::GetLocalSpeed() const
{
	Vec2 forward = GetForwardVector();
	return Vec2(speed.dot(forward), speed.dot(Vec2(-forward.y, forward.x)));
}

const NavigationPoint & Agent::GetNavigationPoint() const
{
	return position;
}

Sector * Agent::GetSector() const
{
	return position.GetSector();
}

bool Agent::IsEnabled() const
{
	return position.IsSet();
}

double Agent::GetRadius() const
{
	return radius;
}

double Agent::GetSightRadius() const
{
	return visibilityRadius;
}

double Agent::GetPersonalSpaceRadius() const
{
	return radius + personalSpaceDistance;
}

double Agent::GetAdaptivePersonalSpaceRadius() const
{
	// Adaptive personal space varies between the full personal space radius and just the agent radius, depending on crowd density
	return radius + (1.0 - localCrowdDensity) * personalSpaceDistance;
}

Vec2 Agent::GetForwardVector() const
{
	return Vec2(cos(orientation), sin(orientation));
}

bool Agent::IsOnPlatform() const
{
	return isOnPlatform;
}


AgentStatusGoal Agent::GetGoalStatus() const
{
	return statusGoal;
}
AgentStatusPath Agent::GetPathStatus() const
{
	return statusPath;
}


void Agent::NotifyNewWalkableArea(const Polygon & polygon)
{
	// No need to update a path if there is no path or the path needs updating already
	if (statusGoal != AGENTSTATUS_GOAL_POINT_NEAR_GOAL_REACHED)
	{
		if (!globalPath.path.IsSet() || globalPath.path.NeedsReplanning())
			return;
	}

	bool replanPath = false;

	// If the path does not reach its goal yet, always replan the path
	if (statusGoal == AGENTSTATUS_GOAL_POINT_NEAR_GOAL_REACHED || !globalPath.path.ReachesGoal())
	{
		replanPath = true;
		if (statusPath != AGENTSTATUS_PATH_MOVED_AGENT_PATH_UPDATED)
			statusPath = AGENTSTATUS_PATH_IMPROVED_PATH_FOUND_AND_UPDATED;
	}
	// If there is a possibility of a shorter path through the given polygon, mark the path for replanning
	// The check here is very rough and is aimed at excluding cases where passing the polygon is clearly not faster
	else if (polygon.Intersects(position.GetLocalPosition(), globalPath.goals.front()))
	{
		replanPath = true;
		if (statusPath != AGENTSTATUS_PATH_MOVED_AGENT_PATH_UPDATED)
			statusPath = AGENTSTATUS_PATH_FASTER_PATH_FOUND_AND_UPDATED;
	}
	else
	{
		for (auto & point : polygon.Points())
		{
			if ((point - position.GetLocalPosition()).length() + (point - globalPath.goals.front()).length() < globalPath.remainingDistance)
			{
				replanPath = true;
				if (statusPath != AGENTSTATUS_PATH_MOVED_AGENT_PATH_UPDATED)
					statusPath = AGENTSTATUS_PATH_FASTER_PATH_FOUND_AND_UPDATED;
				break;
			}
		}
	}

	if (replanPath)
	{
		globalPath.path.SetNeedsReplanning();
		statusSetPathChanged = true;
	}
}


void Agent::SetDesiredSpeed(Vec2 desiredSpeed)
{
	this->desiredSpeed = desiredSpeed;
}

std::tuple<Vec2, double> Agent::GetNearestObstacleAndCenterObstacleDistance() const
{
	Vec2 nearestObstacle = ExplicitCorridorMap::FindNearestObstaclePointAtPoint(position.GetEdgeSegment().get(), GetPosition());
	double centerObstacleDistance = (position.GetEdgeSegment()->getClosestPointOnMedialAxisAtPoint(GetPosition()) - nearestObstacle).length();
	return std::make_tuple(nearestObstacle, centerObstacleDistance);
}

std::tuple<Vec2, Vec2, Vec2> Agent::GetSuggestedPathing(Vec2 nearestObstacle, double centerObstacleDistance)
{
	Path * activePath = nullptr;
	if (globalPath.path.IsSet())
		activePath = &globalPath;

	if (!activePath)
		return std::make_tuple(Vec2(0.0, 0.0), Vec2(0.0, 0.0), Vec2(0.0, 0.0));

	Vec2 currentPosition = position.GetLocalPosition();
	Vec2 toNearestObstacle = nearestObstacle - currentPosition;
	double clearDistance = toNearestObstacle.length();
	Vec2 nearestPoint, pathDirection;
	std::tie(nearestPoint, pathDirection) = getNearestPointAndDirection(*activePath, clearDistance);

	// When the agent is far from the local path, move more to the attraction point
	// Otherwise, follow the path direction
	Vec2 toNearestPoint = nearestPoint - currentPosition;
	Vec2 toNearestPointDirection = toNearestPoint.safe_normalized();
	double steerBackToPathFactor = 0.2 * toNearestPoint.length() / centerObstacleDistance;
	// If the agent gets close to an obstacle in the direction of the path, steer back to the path
	double distanceToObstacleInPathDirection = toNearestPoint.length() / std::max(0.1, toNearestPointDirection.dot(pathDirection.normalized()));
	steerBackToPathFactor = lerp(steerBackToPathFactor, 1.0, std::min(1.0, distanceToObstacleInPathDirection / radius));
	Vec2 pathingDirection = lerp(pathDirection, toNearestPointDirection, steerBackToPathFactor).safe_normalized();

	// Steer towards goal near end of path
	double nearGoalDistance = std::max(0.01 * radius, 0.5 * speed.dot(speed) / maxAcceleration);
	double nearGoalFactor = std::min(std::max(1.5 - activePath->remainingDistance / nearGoalDistance, 0.0), 1.0);
	if (activePath->nearestPoint.t == 1.0)
	{
		pathingDirection = toNearestPointDirection;
	}
	else
	{
		Vec2 toGoal = Vec2(activePath->path.GetEndPoint()) - currentPosition;
		pathingDirection = lerp(pathingDirection, toGoal, nearGoalFactor).normalized();
	}

	return std::make_tuple(nearestPoint, pathDirection, pathingDirection);
}



void Agent::computeLocalCrowdDensity(const std::vector<Agent *> & nearbyAgents, double centerObstacleDistance)
{
	// Determine local density using a quarter of the sight radius
	double visibleArea = M_PI * GetSightRadius() * 0.25 * std::min(GetSightRadius() * 0.25, centerObstacleDistance);
	double visibleAgentArea = 0.0;
	for (auto agent : nearbyAgents)
	{
		Vec2 toAgent = agent->GetPosition() - GetPosition();
		if (GetForwardVector().dot(toAgent.normalized()) > 0.0 && toAgent.length() < 0.25 * GetSightRadius())
			visibleAgentArea += M_PI * agent->GetRadius() * agent->GetRadius();
	}
	// Fully crowded when a fifth of the visible area is occupied by agents
	localCrowdDensity = std::min(1.0, visibleAgentArea * 5.0 / visibleArea);
}


Vec2 Agent::getPathingForce(Path & path, Vec2 nearestObstacle, double centerObstacleDistance, double nearGoalFactor)
{
	double Sp = 1.0;

	Vec2 currentPosition = position.GetLocalPosition();
	Vec2 toNearestObstacle = nearestObstacle - currentPosition;
	double clearDistance = toNearestObstacle.length();
	Vec2 nearestPoint, pathDirection;
	std::tie(nearestPoint, pathDirection) = getNearestPointAndDirection(path, clearDistance);

	// When the agent is far from the local path, move more to the attraction point
	// Otherwise, follow the path direction
	Vec2 toNearestPoint = nearestPoint - currentPosition;
	Vec2 toNearestPointDirection = toNearestPoint.safe_normalized();
	double steerBackToPathFactor = 0.2 * toNearestPoint.length() / centerObstacleDistance;
	// If the agent gets close to an obstacle in the direction of the path, steer back to the path
	double distanceToObstacleInPathDirection = toNearestObstacle.length() / std::max(0.1, toNearestObstacle.safe_normalized().dot(pathDirection.normalized()));
	steerBackToPathFactor = lerp(steerBackToPathFactor, 1.0, std::min(radius, toNearestPoint.length()) / std::max(radius, distanceToObstacleInPathDirection));
	Vec2 pathingDirection = lerp(pathDirection, toNearestPointDirection, steerBackToPathFactor).safe_normalized();

	// Steer towards goal near end of path
	if (path.nearestPoint.t == 1.0)
	{
		pathingDirection = toNearestPointDirection;
	}
	else
	{
		Vec2 toGoal = Vec2(path.goals.front()) - currentPosition;
		pathingDirection = lerp(pathingDirection, toGoal, nearGoalFactor).normalized();
	}

	return pathingDirection * Sp;
}

std::tuple<Vec2, Vec2> Agent::getNearestPointAndDirection(Path & path, double clearDistance)
{
	Vec2 currentPosition = position.GetLocalPosition();
	auto & pathPoints = path.path.GetPoints();

	Vec2 nearestPoint = lerp(pathPoints[path.nearestPoint.segment], pathPoints[path.nearestPoint.segment + 1], path.nearestPoint.t);
	Vec2 pathSegmentVector = pathPoints[path.nearestPoint.segment + 1] - pathPoints[path.nearestPoint.segment];
	double advanceAlongSegment;
	while ((advanceAlongSegment = pathSegmentVector.normalized().dot(currentPosition - nearestPoint)) > 0.0)
	{
		// Advance along segment
		double newT = path.nearestPoint.t + advanceAlongSegment / pathSegmentVector.length();
		if (newT < 1.0)
		{
			// Advancement does not progress beyond segment end
			path.remainingDistanceFromNearestPoint -= advanceAlongSegment;
			path.nearestPoint.t = newT;
			nearestPoint = lerp(pathPoints[path.nearestPoint.segment], pathPoints[path.nearestPoint.segment + 1], path.nearestPoint.t);
			break;
		}
		else if (path.nearestPoint.segment < (int)pathPoints.size() - 2)
		{
			// Advancement moves to next segment
			path.remainingDistanceFromNearestPoint -= (1.0 - path.nearestPoint.t) * pathSegmentVector.length();
			path.nearestPoint.t = 0.0;
			++path.nearestPoint.segment;
			nearestPoint = lerp(pathPoints[path.nearestPoint.segment], pathPoints[path.nearestPoint.segment + 1], path.nearestPoint.t);
			pathSegmentVector = pathPoints[path.nearestPoint.segment + 1] - pathPoints[path.nearestPoint.segment];
		}
		else
		{
			// Advancement moves to end of path
			path.remainingDistanceFromNearestPoint = 0.0;
			path.nearestPoint.t = 1.0;
			nearestPoint = pathPoints[path.nearestPoint.segment + 1];
			break;
		}
	}

	// Slight underestimate of remainingDistance but overall a very accurate depiction
	path.remainingDistanceFromNearestPoint = std::max(0.0, path.remainingDistanceFromNearestPoint);
	double distanceToNearestPoint = (currentPosition - nearestPoint).length();
	path.remainingDistance = sqrt(path.remainingDistanceFromNearestPoint * path.remainingDistanceFromNearestPoint + distanceToNearestPoint * distanceToNearestPoint);

	// Find a smooth interpolated pathing direction
	// The range around a point where interpolation occurs is limited by the agent radius
	Vec2 smoothPathDirection;
	if (path.nearestPoint.t < 0.5)
	{
		if (path.nearestPoint.segment > 0)
		{
			double interpolateT = std::max(path.nearestPoint.t, 0.5 * path.nearestPoint.t * pathSegmentVector.length() / radius);
			interpolateT = std::min(1.0, interpolateT + 0.5);
			smoothPathDirection = lerp((pathPoints[path.nearestPoint.segment] - pathPoints[path.nearestPoint.segment - 1]).normalized(), pathSegmentVector.normalized(), interpolateT).normalized();
		}
		else
		{
			smoothPathDirection = pathSegmentVector.normalized();
		}
	}
	else
	{
		if (path.nearestPoint.segment < (int)pathPoints.size() - 2)
		{
			double interpolateT = std::max((1.0 - path.nearestPoint.t), 0.5 * (1.0 - path.nearestPoint.t) * pathSegmentVector.length() / radius);
			interpolateT = std::max(0.0, 0.5 - interpolateT);
			smoothPathDirection = lerp(pathSegmentVector.normalized(), (pathPoints[path.nearestPoint.segment + 2] - pathPoints[path.nearestPoint.segment + 1]).normalized(), interpolateT).normalized();
		}
		else
		{
			smoothPathDirection = pathSegmentVector.normalized();
		}
	}

	return std::make_tuple(nearestPoint, smoothPathDirection);
}

Vec2 Agent::getBoundaryForce(Vec2 obstaclePoint, double centerObstacleDistance, double remainingDistance, double nearGoalFactor, double deltaTime) const
{
	double Sb = 0.0 * (1.0 - localCrowdDensity) * (1.0 - nearGoalFactor);

	Vec2 vecFromObstacle = (GetPosition() - obstaclePoint);
	double distance = vecFromObstacle.length();

	// Compute safe distance to obstacles
	double ds = safeDistance * std::min(1.0, remainingDistance / safeDistance);
	// clamp safe distance to avoid collisions with obstacles
	//ds = std::max(maxMovementSpeed * deltaTime, ds);
	// and adjust safe distance to the preferred distance based on the size of the corridor
	ds = NavigationPath::GetPreferredSafeDistance(radius, ds, centerObstacleDistance);

	if (distance < ds)
	{
		//return vecFromObstacle.normalized() * ((ds - distance) / std::max(0.001 * radius, distance)) * Sb;
		return vecFromObstacle.normalized() * (1.0 - distance / ds) * Sb;
	}
	return Vec2(0.0, 0.0);
}

Vec2 Agent::getCollisionForce(const std::vector<Agent *> & nearbyAgents) const
{
	// Decrease collision force as crowd gets more dense
	double Sc = 5.0 * (1.0 - 0.8 * localCrowdDensity);

	Vec2 currentPosition = position.GetLocalPosition();

	Vec2 force = Vec2(0.0, 0.0);

	std::map<double, Agent *> nearestAgents;

	// Push agent away from other agent if their radius overlaps this agent's personal radius
	for (auto agent : nearbyAgents)
	{
		if (agent == this)
			continue;
		Vec2 fromAgent = currentPosition - agent->position.GetLocalPosition();
		double distance = fromAgent.length();
		nearestAgents.emplace(distance, agent);
	}

	if (!nearestAgents.empty())
	{
		auto agent = nearestAgents.begin()->second;
		Vec2 fromAgent = currentPosition - agent->position.GetLocalPosition();
		double distance = fromAgent.length();
		if (distance < GetPersonalSpaceRadius() + agent->radius)
		{
			force += fromAgent.safe_normalized() * ((GetPersonalSpaceRadius() + agent->radius - distance) / (GetPersonalSpaceRadius() + agent->radius));
		}
	}

	return force * Sc;
}

Vec2 Agent::getRandomForce() const
{
	double Sr = 0.001;

	Vec3 position = GetPosition();
	std::hash<double> hash;
	std::default_random_engine random_engine((int)(hash(position.x) ^ hash(position.y) ^ hash(position.z)));
	std::uniform_real_distribution<double> distribution(0.0, 2.0 * M_PI);
	double randomAngle = distribution(random_engine);
	return Vec2(cos(randomAngle), sin(randomAngle)) * Sr;
}


void Agent::applyCrowdStream(Vec2 & desiredSpeed, const std::vector<Agent *> & nearbyAgents) const
{
	// Following "On Streams and Incentives: A Synthesis of Individual and Collective Crowd Motion"
	// by van Goethem et al.

	// Here we compute the local stream velocity based on up to 5 nearby agents
	Vec2 localStreamVelocity = Vec2(0.0, 0.0);
	double localStreamVelocityMagnitude = 0.0;
	int numNearbyAgentsCounted = 0;

	// Sorted set of nearby agents
	std::map<double, Agent *> nearestVisibleAgents;

	// Get up to 5 nearby agents within the FOV that move roughly in the same direction
	for (auto nearbyAgent : nearbyAgents)
	{
		// Skip self
		if (nearbyAgent == this)
			continue;
		// Within FOV only
		Vec2 toNearbyAgent = Vec2(nearbyAgent->GetPosition() - GetPosition());
		if (toNearbyAgent.dot(GetForwardVector()) < 0.0)
			continue;
		// Similar movement direction only
		if (nearbyAgent->speed.dot(desiredSpeed) <= 0.0)
			continue;
		// Disallow agents moving towards this agent
		if (nearbyAgent->speed.dot(GetForwardVector()) <= 0.0)
			continue;

		nearestVisibleAgents.emplace(toNearbyAgent.length(), nearbyAgent);
		// Limit to 5
		if (nearestVisibleAgents.size() == 5)
			break;
	}

	for (auto nearbyDistanceAndAgent : nearestVisibleAgents)
	{
		auto nearbyAgent = nearbyDistanceAndAgent.second;
		Vec2 toNearbyAgent = Vec2(nearbyAgent->GetPosition() - GetPosition());

		// Get perceived velocity per agent as:
		// lerp(normalized velocity, normalized vector to agent, density * distance to agent / sight radius) normalized * magnitude of agent velocity
		Vec2 perceivedVelocity = lerp(nearbyAgent->speed.safe_normalized(), toNearbyAgent.safe_normalized(), localCrowdDensity * toNearbyAgent.length() / GetSightRadius());
		// Local stream velocity is:
		// Averaged vector-wise perceived velocity of nearby agents, with separately averaged magnitude computation
		localStreamVelocity += perceivedVelocity;
		localStreamVelocityMagnitude += perceivedVelocity.length();

		++numNearbyAgentsCounted;
	}

	// No nearby agents to match velocity to? Nothing more to do
	if (numNearbyAgentsCounted == 0)
		return;

	// Local stream velocity is:
	// Averaged vector-wise perceived velocity of nearby agents, with separately averaged magnitude computation
	localStreamVelocity = localStreamVelocity.normalized() * localStreamVelocityMagnitude / numNearbyAgentsCounted;

	// Get the incentive to follow a personal path
	// First compute the angle between the stream velocity and the individual velocity
	double angle = acos(localStreamVelocity.normalized().dot(desiredSpeed.normalized()));
	// Then compute the deviation factor, the willingness to adapt to that angle
	double psi = std::min(std::max((angle - 0.4) / 0.4, 0.0), 1.0);
	double incentive = std::max(pow(1.0 - localCrowdDensity, 3.0), psi);

	desiredSpeed = lerp(localStreamVelocity, desiredSpeed, incentive);
}


void Agent::applyCollisionAvoidance(Vec2 & desiredSpeed, const std::vector<Agent *> & nearbyAgents, double remainingDistance) const
{
	// Following "A Predictive Collision Avoidance Model for Pedestrian Simulation"
	// by Karamouzas et al.

	double Sa = 0.4;

	// Perform avoidance on a slightly larger radius and falloff towards a smaller radius
	double softnessLower = 0.95;
	double softnessUpper = 1.35;

	// Do not perform collision avoidance if not moving
	if (speed.length() == 0.0)
		return;

	Vec2 currentPosition = position.GetLocalPosition();

	std::map<double, std::pair<double, Agent *>> collisions;
	for (auto agent : nearbyAgents)
	{
		if (agent == this)
			continue;
		Vec2 relativeSpeed = speed - agent->speed;
		Vec2 agentPosition = agent->position.GetLocalPosition();
		Vec2 toAgent = agentPosition - GetPosition();
		double inFrontFactor = toAgent.dot(speed.safe_normalized());
		// Ignore agents not in front of this agent
		//if (inFrontFactor <= 0.0)
		//	continue;
		// Ignore agents that already collide with this agent
		double combinedRadii = (GetAdaptivePersonalSpaceRadius() + agent->radius) * softnessUpper;
		if (toAgent.length() < combinedRadii)
			collisions.emplace(0.0, std::make_pair(0.0, agent));

		// Regarding agent to agent collision detection, where each agent moves with a constant velocity, there are two simplifications:
		// - We can lock the position of one agent and instead move the other agent by their relative speed
		// - We can reduce one agent's radius to zero and increase the other agent's radius to the sum of their radii
		// This reduces the problem to a line-circle intersection
		double t1, t2;
		if (lineSegmentIntersectsCircle(currentPosition, relativeSpeed, agentPosition, combinedRadii, t1, t2))
		{
			// Look ahead into the future up to 4 seconds only
			if (t1 < 0.0 || t1 > 4.0)
				continue;
			// Check if the collision happens before reaching the goal
			if (t1 * speed.length() > remainingDistance)
				continue;
			collisions.emplace(t1 + 4.0 * (1.0 - inFrontFactor), std::make_pair(t1, agent));
		}
	}

	Vec2 avoidanceForce = Vec2(0.0, 0.0);
	int numCollisions = 0;
	double multipleAgentFactor = 1.0;
	for (auto & collision : collisions)
	{
		if (++numCollisions > 3)
			break;
		auto collisionTime = collision.second.first;
		auto agent = collision.second.second;
		Vec2 agentPosition = agent->position.GetLocalPosition();
		Vec2 positionAtCollision = (currentPosition + speed * collisionTime);
		Vec2 agentPositionAtCollision = (agentPosition + agent->speed * collisionTime);
		// distanceFactor is a piecewise function to decrease the avoidance for collisions that are far away
		double distanceFactor = (collisionTime * speed.length()) + (positionAtCollision - agentPositionAtCollision).length() - GetAdaptivePersonalSpaceRadius() - agent->radius;
		if (distanceFactor > GetSightRadius())
			distanceFactor = std::max(0.0, 2.0 - distanceFactor / GetSightRadius());
		else if (distanceFactor > 0.4 * GetSightRadius())
			distanceFactor = 1.0;
		else
			distanceFactor = std::min(4.0, 0.4 * GetSightRadius() / std::max(0.001 * radius, distanceFactor));
		// avoid by applying a force away from the point of first collision
		Vec2 avoidDirection = (positionAtCollision - agentPositionAtCollision).safe_normalized();
		double falloffPoint = 1.0 - softnessLower / softnessUpper;
		double falloffFactor = std::min(std::max(speed.safe_normalized().dot(-avoidDirection) / falloffPoint, 0.0), 1.0);
		double directionFactor = std::max(0.0, avoidDirection.dot(-speed.safe_normalized()));
		avoidanceForce += avoidDirection * falloffFactor * directionFactor * distanceFactor * multipleAgentFactor;
		multipleAgentFactor *= 0.6;
	}

	if (numCollisions > 0)
	{
		avoidanceForce *= Sa / numCollisions;
		applyDirectionalFactors(avoidanceForce, GetForwardVector(), 0.0, 1.0, 0.4, avoidanceForce, false);
		desiredSpeed += avoidanceForce * maxMovementSpeed;
	}
}


void Agent::reduceDesiredSpeedIntoBoundary(Vec2 & desiredSpeed, Vec2 obstaclePoint)
{
	Vec2 vecToObstacle = (obstaclePoint - GetPosition());
	double distance = vecToObstacle.length();

	// Start reduction at 1.75x agent radius and reduce fully at 1.25x agent radius
	double reductionFactor = std::min(1.0, (1.75 / 0.25) - distance / radius / 0.25);
	if (reductionFactor > 0.0)
		desiredSpeed -= vecToObstacle * (reductionFactor * std::max(0.0, desiredSpeed.dot(vecToObstacle)) / vecToObstacle.dot(vecToObstacle));
}


void Agent::applyCollisionResolution(Vec2 & desiredSpeed, Vec2 nearestObstacle, const std::vector<Agent *> & nearbyAgents) const
{
	const double Srb = 20.0;
	const double Sra = 10.0;

	Vec2 nearestObstacleToAgent = (GetPosition() - nearestObstacle);
	double distanceToNearestObstacle = nearestObstacleToAgent.length();
	if (distanceToNearestObstacle < radius && distanceToNearestObstacle > 0.0)
		desiredSpeed += nearestObstacleToAgent.normalized() * (radius - distanceToNearestObstacle) * Srb;

	for (auto nearbyAgent : nearbyAgents)
	{
		Vec2 nearbyAgentToAgent = GetPosition() - nearbyAgent->GetPosition();
		double distanceToNearbyAgent = nearbyAgentToAgent.length();
		if (distanceToNearbyAgent < radius + nearbyAgent->radius && distanceToNearbyAgent > 0.0)
			desiredSpeed += nearbyAgentToAgent.normalized() * (radius + nearbyAgent->radius - distanceToNearbyAgent) * Sra;
	}
}


bool Agent::lineSegmentIntersectsCircle(Vec2 lineStart, Vec2 lineDirection, Vec2 circleCenter, double circleRadius, double & t1, double & t2)
{
	Vec2 circleToLineStart = lineStart - circleCenter;

	double a = lineDirection.dot(lineDirection);
	double b = 2.0 * circleToLineStart.dot(lineDirection);
	double c = circleToLineStart.dot(circleToLineStart) - circleRadius * circleRadius;

	double D = b * b - 4.0 * a * c;
	if (D < 0.0 || a == 0.0)
		return false;
	D = sqrt(D);

	t1 = (-b - D) / (2.0 * a);
	t2 = (-b + D) / (2.0 * a);

	if (t1 > 1.0 || t2 < 0.0)
		return false;
	return true;
}


void Agent::limitMagnitudeByDirectionalFactors(Vec2 & vector, double magnitude, const Vec2 & forwardVector, double forwardFactor, double sidewaysFactor, double backwardsFactor, const Vec2 & factorDirection, bool adjustInFactorDirectionOnly)
{
	double inverseForwardFactor = (forwardFactor == 0.0 ? 0.0 : 1.0 / forwardFactor);
	double inverseSidewaysFactor = (sidewaysFactor == 0.0 ? 0.0 : 1.0 / sidewaysFactor);
	double inverseBackwardsFactor = (backwardsFactor == 0.0 ? 0.0 : 1.0 / backwardsFactor);

	applyDirectionalFactors(vector, forwardVector, inverseForwardFactor, inverseSidewaysFactor, inverseBackwardsFactor, factorDirection, adjustInFactorDirectionOnly);
	if (vector.length() > magnitude)
		vector = vector.normalized() * magnitude;
	applyDirectionalFactors(vector, forwardVector, forwardFactor, sidewaysFactor, backwardsFactor, factorDirection, adjustInFactorDirectionOnly);
}

void Agent::applyDirectionalFactors(Vec2 & vector, const Vec2 & forwardVector, double forwardFactor, double sidewaysFactor, double backwardsFactor, const Vec2 & factorDirection, bool adjustInFactorDirectionOnly)
{
	double forward = vector.dot(forwardVector);
	Vec2 forwardComponent = forwardVector * forward;
	Vec2 sidewaysComponent = vector - forwardComponent;
	forwardFactor = (forward > 0.0 ? forwardFactor : backwardsFactor);
	if (adjustInFactorDirectionOnly)
	{
		if (forwardComponent.dot(factorDirection) < 0.0)
			forwardFactor = 1.0;
		if (sidewaysComponent.dot(factorDirection) < 0.0)
			sidewaysFactor = 1.0;
	}
	vector = forwardComponent * forwardFactor + sidewaysComponent * sidewaysFactor;
}