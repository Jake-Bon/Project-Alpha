/*
Distributed under the Unity Asset Store EULA as given in
https://unity3d.com/legal/as_terms
*/

#pragma once


enum AgentStatusGoal
{
	// No Goal is set
	AGENTSTATUS_GOAL_NO_GOAL_SET = 0,
	// The Agent is moving towards a Goal
	AGENTSTATUS_GOAL_MOVING_TOWARDS_GOAL = 1,
	// The Agent is close to a Goal and has begun slowing down
	AGENTSTATUS_GOAL_NEARING_GOAL_SLOWING_DOWN = 2,
	// The Agent is close to a Goal and has begun moving towards a next Goal
	AGENTSTATUS_GOAL_NEARING_GOAL_MOVING_TO_NEXT = 3,
	// The last goal has been reached
	AGENTSTATUS_GOAL_GOAL_REACHED = 4,
	// The Agent is moving towards a Goal
	AGENTSTATUS_GOAL_MOVING_TOWARDS_POINT_NEAR_GOAL = 5,
	// The Agent is close to a Goal and has begun slowing down
	AGENTSTATUS_GOAL_NEARING_POINT_NEAR_GOAL_SLOWING_DOWN = 6,
	// The last goal has been reached
	AGENTSTATUS_GOAL_POINT_NEAR_GOAL_REACHED = 7
};

enum AgentStatusPath
{
	// The Agent is not following a path
	AGENTSTATUS_PATH_NOT_FOLLOWING_PATH = 0,
	// The Agent is following a path
	AGENTSTATUS_PATH_FOLLOWING_PATH = 1,
	// The Agent was following a path, but it was recently obstructed
	AGENTSTATUS_PATH_PATH_OBSTRUCTED_AND_UPDATED = 2,
	// The Agent was following a path, but could no longer see its nearest point
	// The path has been updated
	AGENTSTATUS_PATH_PATH_LOST_AND_UPDATED = 3,
	// The Agent was following a path, but found a faster alternative
	// The path has been updated
	AGENTSTATUS_PATH_FASTER_PATH_FOUND_AND_UPDATED = 4,
	// The Agent was following a path, but found a path leading closer to its goal
	// The path has been updated
	AGENTSTATUS_PATH_IMPROVED_PATH_FOUND_AND_UPDATED = 5,
	// The Agent was following a path, but was moved to a new position
	// The path has been updated
	AGENTSTATUS_PATH_MOVED_AGENT_PATH_UPDATED = 6
};
